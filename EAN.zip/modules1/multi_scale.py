import torch.nn as nn
import torch


def conv_3x3(in_channels=3, out_channels=64, kernel_size=3, padding=1):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True)
    )


def conv_dia(in_channels=512, out_channels=128, kernel_size=3, dilation=8, padding=8):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, dilation=dilation,
                  padding=padding),
        nn.BatchNorm2d(out_channels)
    )


class MultiScale(nn.Module):
    # 512->128  3 2 2
    def __init__(self, in_channels=512, out_channels=256, kernel_size=3, dilation=1, padding=1):
        super(MultiScale, self).__init__()

        self.dia_conv2 = conv_dia(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                  dilation=dilation * 2, padding=padding * 2)
        self.dia_conv4 = conv_dia(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                  dilation=dilation * 4, padding=padding * 4)
        self.dia_conv8 = conv_dia(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                  dilation=dilation * 8, padding=padding * 8)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dia2 = self.dia_conv2(x)
        dia4 = self.dia_conv4(x)
        dia8 = self.dia_conv8(x)
        # 1024
        MVFeature = torch.cat((dia2, dia4, dia8, x), 1)
        return MVFeature
