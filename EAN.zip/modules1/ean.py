import torch
import torch.nn as nn
from .noise_module import NoiseNet
from .encoder import Encoder
from .edge_module import Edge
from .feature_fusion import FeatureFusion


class ConvBlock(nn.Module):
    def __init__(self, inplanes, midplanes, planes):
        super(ConvBlock, self).__init__()
        self.conv1 = conv_3x3(inplanes, midplanes)
        self.conv2 = conv_3x3(midplanes, planes)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)

        return x


def conv_3x3(in_channels, out_channels, kernel_size=3, padding=1):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True)
    )


class EAN(nn.Module):
    def __init__(self, n_class, **kwargs):
        super(EAN, self).__init__()
        self.num_class = n_class

        self.r_net = Encoder()
        self.n_net = NoiseNet()
        self.edge_net = Edge()
        self.fea_fusion = FeatureFusion()



        # 窗口大小2 步长2 向上取整模式
        self.pool2 = nn.MaxPool2d(2, 2, ceil_mode=True)
        self.pool4 = nn.MaxPool2d(4, 4, ceil_mode=True)
        self.pool8 = nn.MaxPool2d(8, 8, ceil_mode=True)
        self.upsample_2 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.upsample_4 = nn.Upsample(scale_factor=4, mode="bilinear", align_corners=True)
        self.upsample_8 = nn.Upsample(scale_factor=8, mode="bilinear", align_corners=True)
        self.upsample_16 = nn.Upsample(scale_factor=16, mode="bilinear", align_corners=True)
        self.upsample_32 = nn.Upsample(scale_factor=32, mode="bilinear", align_corners=True)
        self.upsample_64 = nn.Upsample(scale_factor=64, mode="bilinear", align_corners=True)

        self.conv_dp = nn.Conv2d(1024, 512, 3, padding=1)
        self.conv_14 = ConvBlock(inplanes=1024, midplanes=512, planes=128)
        self.conv_12 = ConvBlock(inplanes=256, midplanes=128, planes=64)

        # mask output
        self.out_edge = nn.Conv2d(512, 1, 1, padding=0)
        self.outconv14 = nn.Conv2d(1024, 1, 1, padding=0)
        self.outconv12 = nn.Conv2d(256, 1, 1, padding=0)
        self.outconv128 = nn.Conv2d(128, 1, 1, padding=0)

    def forward(self, x):
        # resnet 4个模块的输出特征以及  最后再次经过3个BasicBlock模块的深层特征
        # r 64*512* r12 128*256 r14 512*64* r15 512*32*
        r, r1_2, r1_4, r1_5 = self.r_net(x)
        n, n1_2, n1_4 = self.n_net(x)

        #    2. 融合边界信息  边界特征多尺度
        edge_feature = self.edge_net(r, r1_2, r1_4, n, n1_2, n1_4)
        # 最后输出为512 * 256 * 256

        deep_feature = self.fea_fusion(r1_5, edge_feature, n1_4)
        # 最后输出为1024*64

        #  unet类型特征融合  边缘特征+浅层特征->decoder
        # 后期考虑修改成反卷积/转置卷积
        # 512*64   1024*64
        r1_4 = torch.cat((r1_4, self.conv_dp(deep_feature)), dim=1)

        out4 = self.upsample_8(r1_4)
        out4 = self.outconv14(out4)
        out4 = torch.sigmoid(out4)

        r1_4 = self.conv_14(r1_4)
        # 128 + 128
        r1_2 = torch.cat((r1_2, self.upsample_4(r1_4)), dim=1)

        out2 = self.upsample_2(r1_2)
        out2 = self.outconv12(out2)
        out2 = torch.sigmoid(out2)

        # 256-64
        r1_2 = self.conv_12(r1_2)
        # 64+64
        r = torch.cat((r, self.upsample_2(r1_2)), dim=1)
        out1 = self.outconv128(r)
        out1 = torch.sigmoid(out1)

        # 512*256*256  输出的边界图像是256*256的
        out_e = self.out_edge(edge_feature)
        out_e = torch.sigmoid(out_e)

        return out1, out2, out4, out_e


if __name__ == '__main__':
    img = torch.randn(2, 3, 512, 512)
    model = EAN(n_class=1)
    out1, out2, out4, out_e = model(img)
    print(out1.shape)
