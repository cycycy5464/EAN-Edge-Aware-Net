import torch
import torch.nn as nn


class SelfAttention(nn.Module):
    def __init__(self, in_channels):
        super(SelfAttention, self).__init__()

        self.query = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        batch_size, channels, height, width = x.size()

        # 计算查询（query）、键（key）和值（value）
        query = self.query(x).view(batch_size, -1, height * width).permute(0, 2, 1)
        key = self.key(x).view(batch_size, -1, height * width)
        value = self.value(x).view(batch_size, -1, height * width)

        # 计算注意力权重
        attention_weights = torch.bmm(query, key)
        attention_weights = self.softmax(attention_weights)

        # 特征融合
        attended_value = torch.bmm(value, attention_weights.permute(0, 2, 1))
        attended_value = attended_value.view(batch_size, channels, height, width)

        # 输出融合后的特征张量
        output = x + attended_value

        return output

class GlobalAttention(nn.Module):
    def __init__(self, in_channels):
        super(GlobalAttention, self).__init__()

        self.query = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.alpha = nn.Parameter(torch.ones(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        batch_size, channels, height, width = x.size()

        # 计算查询（query）、键（key）和值（value）
        query = self.query(x).view(batch_size, -1, height * width).permute(0, 2, 1)
        key = self.key(x).view(batch_size, -1, height * width)
        value = self.value(x).view(batch_size, -1, height * width)

        # 计算注意力权重
        attention_weights = torch.bmm(query, key)
        attention_weights = self.softmax(attention_weights)

        # 特征融合
        attended_value = torch.bmm(value, attention_weights.permute(0, 2, 1))
        attended_value = attended_value.view(batch_size, channels, height, width)

        # 输出融合后的特征张量
        output = x + self.alpha * attended_value

        return output


# 通道注意力机制
class ChannelAttention(nn.Module):
    def __init__(self, channel, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // ratio, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // ratio, channel, bias=False)
        )
        self.sig = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y1 = self.max_pool(x).view(b, c)
        y = self.fc(y) + self.fc(y1)
        y = self.sig(y)
        return x * y


class MySpatialAttention(nn.Module):
    def __init__(self,in_channels, kernel_size=7):
        super(MySpatialAttention, self).__init__()

        self.query = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.softmax = nn.Softmax(dim=-1)

        # 宽度上不进行卷积
        self.conv_1_1 = nn.Sequential(nn.Conv2d(channels, channels,
                                  kernel_size=(kernel_size, 1),
                                  padding=(kernel_size // 2, 0)),
                                  nn.ReLU(inplace=True))
        # 高度上不进行卷积
        self.conv_1_2 = nn.Sequential(nn.Conv2d(channels, channels,
                                  kernel_size=(kernel_size, 1),
                                  padding=(0, kernel_size // 2)),
                                  nn.ReLU(inplace=True))

    def forward(self, x):
        batch_size, channels, height, width = x.size()

        # 计算查询（query）、键（key）和值（value）
        query = self.query(x).view(batch_size, -1, height * width).permute(0, 2, 1)
        key = self.key(x).view(batch_size, -1, height * width)
        value = self.value(x).view(batch_size, -1, height * width)

        # 计算注意力权重
        attention_weights = torch.bmm(query, key)
        attention_weights = self.softmax(attention_weights)

        value =self.conv_1_1(value) + self.conv_1_2(value)
        # 特征融合
        attended_value = torch.bmm(value, attention_weights.permute(0, 2, 1))
        attended_value = attended_value.view(batch_size, channels, height, width)

        # 输出融合后的特征张量
        output = x + attended_value
        return output


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x1 = x
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x) * 2 * x1


class MyAttention(nn.Module):
    def __init__(self,in_channels, kernel_size=7):
        super(MyAttention, self).__init__()
        self.g_attention = GlobalAttention(in_channels)
        self.s_attention = MySpatialAttention(in_channels,kernel_size)

    def forward(self, x):
        x1 = self.g_attention(x)
        x2 = self.s_attention(x)

        return x1+x2
