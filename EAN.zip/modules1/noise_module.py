import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from .encoder_n import Encoder_n


def get_sobel(in_chan, out_chan):
    filter_x = np.array([
        [1, 0, -1],
        [2, 0, -2],
        [1, 0, -1],
    ]).astype(np.float32)
    filter_y = np.array([
        [1, 2, 1],
        [0, 0, 0],
        [-1, -2, -1],
    ]).astype(np.float32)

    filter_x = filter_x.reshape((1, 1, 3, 3))
    filter_x = np.repeat(filter_x, in_chan, axis=1)
    filter_x = np.repeat(filter_x, out_chan, axis=0)

    filter_y = filter_y.reshape((1, 1, 3, 3))
    filter_y = np.repeat(filter_y, in_chan, axis=1)
    filter_y = np.repeat(filter_y, out_chan, axis=0)

    filter_x = torch.from_numpy(filter_x)
    filter_y = torch.from_numpy(filter_y)
    filter_x = nn.Parameter(filter_x, requires_grad=False)
    filter_y = nn.Parameter(filter_y, requires_grad=False)
    conv_x = nn.Conv2d(in_chan, out_chan, kernel_size=3, stride=1, padding=1, bias=False)
    conv_x.weight = filter_x
    conv_y = nn.Conv2d(in_chan, out_chan, kernel_size=3, stride=1, padding=1, bias=False)
    conv_y.weight = filter_y
    sobel_x = nn.Sequential(conv_x, nn.BatchNorm2d(out_chan))
    sobel_y = nn.Sequential(conv_y, nn.BatchNorm2d(out_chan))
    return sobel_x, sobel_y


def run_sobel(conv_x, conv_y, input):
    g_x = conv_x(input)
    g_y = conv_y(input)
    g = torch.sqrt(torch.pow(g_x, 2) + torch.pow(g_y, 2))
    return torch.sigmoid(g) * input


def rgb2gray(rgb):
    b, g, r = rgb[:, 0, :, :], rgb[:, 1, :, :], rgb[:, 2, :, :]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
    gray = torch.unsqueeze(gray, 1)
    return gray


class BayarConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=5, stride=1, padding=0):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.minus1 = (torch.ones(self.in_channels, self.out_channels, 1) * -1.000)

        super(BayarConv2d, self).__init__()
        # only (kernel_size ** 2 - 1) trainable params as the center element is always -1
        self.kernel = nn.Parameter(torch.rand(self.in_channels, self.out_channels, kernel_size ** 2 - 1),
                                   requires_grad=True)

    def bayarConstraint(self):
        self.kernel.data = self.kernel.permute(2, 0, 1)
        self.kernel.data = torch.div(self.kernel.data, self.kernel.data.sum(0))
        self.kernel.data = self.kernel.permute(1, 2, 0)
        ctr = self.kernel_size ** 2 // 2
        real_kernel = torch.cat((self.kernel[:, :, :ctr], self.minus1.to(self.kernel.device), self.kernel[:, :, ctr:]),
                                dim=2)
        real_kernel = real_kernel.reshape((self.out_channels, self.in_channels, self.kernel_size, self.kernel_size))
        return real_kernel

    def forward(self, x):
        x = F.conv2d(x, self.bayarConstraint(), stride=self.stride, padding=self.padding)
        return x


class SRMFilter(nn.Module):
    def __init__(self):
        super(SRMFilter, self).__init__()

        q = [4, 12, 2]
        # 定义三个不同的SRM滤波器的权重
        srm_filter1 = torch.tensor([
            [0, 0, 0, 0, 0],
            [0, -1, 2, -1, 0],
            [0, 2, -4, 2, -0],
            [0, -1, 2, -1, 0],
            [0, 0, 0, 0, 0]
        ], dtype=torch.float32)
        srm_filter2 = torch.tensor([
            [-1, 2, -2, 2, -1],
            [2, -6, 8, -6, 2],
            [-2, 8, -12, 8, -2],
            [2, -6, 8, -6, 2],
            [-1, 2, -2, 2, -1]
        ], dtype=torch.float32)  # 定义第二个SRM滤波器的权重
        srm_filter3 = torch.tensor([
            [0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0],
            [0, 1, -2, 1, 0],
            [0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0]
        ], dtype=torch.float32)  # 定义第三个SRM滤波器的权重

        srm_filter1 = srm_filter1 / q[0]
        srm_filter2 = srm_filter2 / q[1]
        srm_filter3 = srm_filter3 / q[2]

        # 将权重转换为二维卷积核
        self.weight1 = nn.Parameter(srm_filter1.unsqueeze(0).unsqueeze(0).expand(1, 3, 5, 5), requires_grad=False)
        self.weight2 = nn.Parameter(srm_filter2.unsqueeze(0).unsqueeze(0).expand(1, 3, 5, 5), requires_grad=False)
        self.weight3 = nn.Parameter(srm_filter3.unsqueeze(0).unsqueeze(0).expand(1, 3, 5, 5), requires_grad=False)

        self.conv = nn.Conv2d(3, 3, kernel_size=5, stride=1, padding=2, bias=False)
        self.weight = nn.Parameter(torch.cat([self.weight1, self.weight2, self.weight3], dim=0), requires_grad=False)
        print(self.weight.size())
        self.conv.weight = self.weight

    def forward(self, x):
        # 将输入图像转为灰度图像
        # gray_x = torch.mean(x, dim=1, keepdim=True)
        # 3*512*512 -> 3*512*512
        # 在灰度图像上应用三个不同的SRM滤波器
        return self.conv(x)


class NoiseNet(nn.Module):
    def __init__(self, n_input=3, n_class=1, sobel=False, constrain=True, srm=False, **kwargs):
        super(NoiseNet, self).__init__()
        self.num_class = n_class

        self.upsample_2 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.upsample_4 = nn.Upsample(scale_factor=4, mode="bilinear", align_corners=True)
        self.sobel = sobel
        self.constrain = constrain

        self.conv_pre = nn.Conv2d(in_channels=6, out_channels=3, kernel_size=3, padding=1)
        if self.sobel:
            print("----------use sobel-------------")
            self.sobel_x1, self.sobel_y1 = get_sobel(256, 1)
            self.sobel_x2, self.sobel_y2 = get_sobel(512, 1)
            self.sobel_x3, self.sobel_y3 = get_sobel(1024, 1)
            self.sobel_x4, self.sobel_y4 = get_sobel(2048, 1)
        if self.constrain:
            print("----------use constrain-------------")
            self.noise_extractor = Encoder_n()
            self.constrain_gray = BayarConv2d(in_channels=1, out_channels=3, padding=2)
            self.constrain_rgb = BayarConv2d(in_channels=3, out_channels=3, padding=2)

    def forward(self, x):
        # 得到x的 HW
        size = x.size()[2:]
        input_ = x.clone()
        x = rgb2gray(x)
        x_gray = self.constrain_gray(x)
        x_rgb = self.constrain_rgb(input_)
        x = torch.cat([x_gray, x_rgb], dim=1)
        x = self.conv_pre(x)
        x1, x2, x4 = self.noise_extractor(x)

        return x1, x2, x4


if __name__ == '__main__':
    img = torch.randn(2, 3, 512, 512)
    model = NoiseNet(n_class=1)
    out1, out2, out3, out4, out5, out6 = model(img)
    # 64*512*512
    print(out1.shape)
    # 64*512*512
    print(out2.shape)
    # 128*256*256
    print(out3.shape)
    # 256*128*128
    print(out4.shape)
    # 512*64*64
    print(out5.shape)
    # 512*32*32
    print(out6.shape)
