import torch.nn as nn
from .resnet_model import BasicBlock
import torch
from .multi_scale import MultiScale
from .self_atten import SelfAttention


def conv_3x3(in_channels=3, out_channels=64, kernel_size=3, padding=1):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True)
    )


class FeatureFusion(nn.Module):
    def __init__(self, in_channels=128 + 256 + 512, out_channels=512):
        super(FeatureFusion, self).__init__()

        self.pool4 = nn.MaxPool2d(4, 4, ceil_mode=True)
        self.pool8 = nn.MaxPool2d(8, 8, ceil_mode=True)
        self.upsample_2 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.mul_scale = MultiScale()
        self.attention = SelfAttention(in_channels=1024)
        self.conv_15 = conv_3x3(in_channels=512, out_channels=512)
        self.conv_mul = conv_3x3(in_channels=1280, out_channels=512)
        self.conv_n = conv_3x3(in_channels=512, out_channels=512)
        self.conv_e1 = conv_3x3(in_channels=512, out_channels=512)
        self.conv_e2 = conv_3x3(in_channels=512, out_channels=512)

    def forward(self, r1_5, edge, noise) -> torch.Tensor:
        # r15 512*32    edge 512*256  noise 512*64
        r1_5 = self.conv_mul(self.mul_scale(r1_5))
        r1_5 = r1_5 + self.conv_e1(self.pool8(edge))
        r1_5 = self.conv_15(r1_5)
        r1_5 = self.upsample_2(r1_5)
        noise = noise + self.conv_e2(self.pool4(edge))
        noise = self.conv_n(noise)

        # 1024*64
        r1_5 = torch.cat((r1_5, noise), dim=1)
        r1_5 = self.attention(r1_5)
        return r1_5
