import torch
from torchvision import models
import torch.nn as nn
from .resnet_model import BasicBlock

def conv_3x3(in_channels=3, out_channels=64, kernel_size=3, padding=1):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True)
    )

class Encoder(nn.Module):
    # 3->64->512 3 1
    def __init__(self, in_channels=3, mid_channels=64, out_channels=512, kernel_size=3, padding=1):
        super(Encoder, self).__init__()

        # 引入resnet34
        resnet = models.resnet34(weights=models.ResNet34_Weights.DEFAULT)
        self.conv_pre = conv_3x3(in_channels=in_channels, out_channels=mid_channels, kernel_size=kernel_size,
                                 padding=padding)
        self.encoder_layer1 = resnet.layer1
        self.encoder_layer2 = resnet.layer2
        self.encoder_layer3 = resnet.layer3
        self.encoder_layer4 = resnet.layer4
        self.pool2 = nn.MaxPool2d(2, 2, ceil_mode=True)
        self.pool4 = nn.MaxPool2d(4, 4, ceil_mode=True)
        self.encoder_layer5 = BasicBlock(out_channels, out_channels)

    def forward(self, x: torch.Tensor):
        # 3->64 * 512*512
        x = self.conv_pre(x)
        # 输出64*512*512
        x1 = self.encoder_layer1(x)
        # 输出128*256*256
        x2 = self.encoder_layer2(x1)

        # 输出256*128*128
        x3 = self.encoder_layer3(x2)
        # 输出512*64*64
        x4 = self.encoder_layer4(x3)

        x5 = self.pool2(x4)

        for i in range(2):
            x5 = self.encoder_layer5(x5)
        # x5  512*32*32
        # 返回5个小模块的结果
        return x1, x2, x4, x5
