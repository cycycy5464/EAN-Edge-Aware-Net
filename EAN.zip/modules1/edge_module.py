import torch.nn as nn
from .resnet_model import BasicBlock
import torch
from .self_atten import SpatialAttention

def conv_3x3(in_channels=3, out_channels=64, kernel_size=3, padding=1):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True)
    )


class Edge(nn.Module):
    # 512->128  3 8 8
    def __init__(self, in_channels=256+256, out_channels=512):
        super(Edge, self).__init__()

        self.pool2 = nn.MaxPool2d(2, 2, ceil_mode=True)
        self.upsample_4 = nn.Upsample(scale_factor=4, mode="bilinear", align_corners=True)
        # 普通卷积 128->128
        self.back_bone = BasicBlock(in_channels, out_channels)
        self.conv_r = conv_3x3(in_channels=128, out_channels=256, kernel_size=3, padding=1)
        self.conv_r14 = conv_3x3(in_channels=1024, out_channels=256, kernel_size=3, padding=1)
        self.conv_ = conv_3x3(in_channels=512, out_channels=256, kernel_size=3, padding=1)
        self.attention = SpatialAttention(kernel_size=7)

        self.conv = conv_3x3(in_channels=in_channels, out_channels=out_channels)

    def forward(self, r, r1_2, r1_4, n, n1_2, n1_4) -> torch.Tensor:
        # 融合隐式边界
        r = torch.cat([r, n], 1)
        # r 64*512->128*512*  加上噪声翻倍通道
        r1_2 = torch.cat([r1_2, n1_2], 1)
        # r12 128*256->256*256*   加上噪声翻倍通道
        r1_4 = torch.cat([r1_4, n1_4], 1)
        # r14 512*64->1024*64   加上噪声翻倍通道

        r = self.pool2(r)
        r = self.conv_r(r)
        r1_4 = self.upsample_4(r1_4)
        r1_4 = self.conv_r14(r1_4)
        r1_2 = r1_2 + r1_4 + r

        r1_2 = torch.cat((r1_2, r), dim=1)
        r1_2 = self.conv_(r1_2)
        r1_2 = torch.cat((r1_4, r1_2), dim=1)
        # 256 + 256
        # 考虑添加一个空间注意力机制
        r1_2 = self.attention(r1_2)

        r1_2 = self.back_bone(r1_2)
        # 最后输出为 512 * 256 * 256

        return r1_2
